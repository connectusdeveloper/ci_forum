<?php

namespace App\View\Components\Wireui\Inputs;

class MaskableInput extends BaseMaskable
{
}
