<?php

namespace App\View\Components\Wireui\Icons;

use Illuminate\View\Component;

class Spinner extends Component
{
    public function render()
    {
        return view('wireui::components.icons.spinner');
    }
}
