<?php

namespace App\View\Components\Wireui;

class Textarea extends Input
{
    protected function getView(): string
    {
        return 'wireui::components.textarea';
    }
}
