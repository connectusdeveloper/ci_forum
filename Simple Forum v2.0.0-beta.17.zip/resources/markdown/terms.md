# Terms of Service

Please update the terms in the settings.
