# Privacy Policy

Please update the policy in the settings.
